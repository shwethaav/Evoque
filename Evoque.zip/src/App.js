
import './App.css';
import RouterComponent from "../src/router/Router";
function App() {
  
  return (
    <RouterComponent />
  );
}

export default App;
